


from django.shortcuts import redirect, render
from firstapp.models import Account, Card, Data, Transaction
from django.http import HttpResponse

def give(request):
    return render(request, 'register.html')

def givelogin(request):
    return render(request, 'login.html')

from django.shortcuts import redirect, render
from firstapp.models import Data

def login(request):
    if request.method == 'GET':
        usernamefrombrowser = request.GET.get("username")
        passfrombrowser = request.GET.get("password")

        if usernamefrombrowser and passfrombrowser:  # Check if both fields are provided
            try:
                userfromdb = Data.objects.get(username=usernamefrombrowser)
                if userfromdb.password == passfrombrowser:
                    request.session['username'] = usernamefrombrowser
                    return redirect('home')  # Redirect to home after successful login
                else:
                    return render(request, "login.html", {'error': "Invalid password"})
            except Data.DoesNotExist:
                return render(request, "login.html", {'error': "User  does not exist"})
    
    # If the request method is not GET or if username/password are not provided
    return render(request, "login.html")  # Render the login page again


def giveregister(request):
    return render(request, 'register.html')

def registration(request):
    if request.method == 'GET':
        usernamefrombrowser = request.GET.get("username")
        passfrombrowser = request.GET.get("password")
        email = request.GET.get("email")

        # Check if the username already exists
        if Data.objects.filter(username=usernamefrombrowser).exists():
            return render(request, "register.html", {'error': "Username already exists"})

        Data.objects.create(username=usernamefrombrowser, password=passfrombrowser, email=email)
        return render(request,"login.html", {'message': "Registration successful, please login"})
    return redirect('giveregister')

def home(request):
    """Displays the home page with user details."""
    username_from_session = request.session.get('username')
    if not username_from_session:
        return redirect('givelogin')

    user_data = Data.objects.filter(username=username_from_session).first()
    if user_data:
        return render(request, 'home.html', {
            'username': user_data.username,
            'email': user_data.email,
        })
    return redirect(request,'home.html')

from django.shortcuts import render, redirect
from firstapp.models import Account  # Import your Account model


def budget(request):
    return render(request, 'Budget.html')

def debit(request):
    return render(request, 'debit.html')

def account(request):
    return render(request, 'Account.html')

def goal(request):
    return render(request, 'Goal.html')

def tran(request):
    return render(request, 'tran.html')


from django.shortcuts import render, redirect
from .models import Account  # Ensure you import your Account model
from django.shortcuts import render, redirect
from .models import Account

def add_account(request):
    if request.method == 'POST':
        # Retrieve form data from POST request
        account_holder_name = request.POST.get("account_holder_name")
        account_number = request.POST.get("account_number")
        ifsc_code = request.POST.get("ifsc_code")
        bank_name = request.POST.get("bank_name")
        balance = request.POST.get("balance")

        # Validate that all required fields are provided
        if account_holder_name and account_number and ifsc_code and bank_name and balance:
            try:
                # Convert balance to the appropriate type (e.g., Decimal)
                balance = float(balance)

                # Create a new account in the database
                Account.objects.create(
                    account_holder_name=account_holder_name,
                    account_number=account_number,
                    ifsc_code=ifsc_code,
                    bank_name=bank_name,
                    balance=balance,
                )

                # Redirect to the dashboard (update the route name as necessary)
                return redirect('dashboard')  # Replace 'dashboard' with your actual route name
            except ValueError:
                # Handle invalid balance input
                error_message = "Invalid balance value. Please enter a valid number."
                return render(request, "Account.html", {'error_message': error_message})

        # Handle missing fields
        error_message = "All fields are required."
        return render(request, "Account.html", {'error_message': error_message})

    # Render the form template for GET requests
    return render(request, "Account.html")

from django.shortcuts import render, redirect
from django.http import JsonResponse
from .models import Account
from django.shortcuts import render
from .models import Account
from decimal import Decimal, InvalidOperation
from .models import Transaction

def dashboard(request):
    account_holder_name = None
    balance = None
    message = None
    error_message = None

    if request.method == 'POST':
        # Handle account holder name submission
        if 'account_holder_name' in request.POST:
            account_holder_name = request.POST.get('account_holder_name').strip()
            if account_holder_name:
                account = Account.objects.filter(account_holder_name=account_holder_name).first()
                if account:
                    balance = account.balance
                else:
                    error_message = f"No account found for '{account_holder_name}'."
            else:
                error_message = "Account holder name cannot be empty."

        # Handle debit/credit operations
        elif 'operation' in request.POST and 'amount' in request.POST:
            try:
                amount = Decimal(request.POST.get('amount', '0').strip())
            except (ValueError, InvalidOperation):
                amount = Decimal(0)

            account_holder_name = request.POST.get('holder_name')
            account = Account.objects.filter(account_holder_name=account_holder_name).first()

            if not account:
                error_message = "Account not found."
            elif amount <= 0:
                error_message = "Amount must be greater than 0."
            else:
                operation = request.POST.get('operation')
                if operation == 'debit':
                    if account.balance >= amount:
                        account.balance -= amount
                        account.save()
                        balance = account.balance
                        message = f"Debited ₹{amount} from your account."

                        # Log the transaction
                        Transaction.objects.create(
                            account=account,
                            transaction_type='debit',
                            amount=amount,
                            description=f"Debited ₹{amount} from account."
                        )
                    else:
                        error_message = "Insufficient balance for debit."
                elif operation == 'credit':
                    account.balance += amount
                    account.save()
                    balance = account.balance
                    message = f"Credited ₹{amount} to your account."

                    # Log the transaction
                    Transaction.objects.create(
                        account=account,
                        transaction_type='credit',
                        amount=amount,
                        description=f"Credited ₹{amount} to account."
                    )
                else:
                    error_message = "Invalid operation."

    return render(
        request,
        'dasboard.html',
        {
            'account_holder_name': account_holder_name,
            'balance': balance,
            'message': message,
            'error_message': error_message,
        },
    )

def add_card(request):
    if request.method == 'POST':
        card_number = request.POST.get("card_number")
        pin = request.POST.get("pin")
        cvv = request.POST.get("cvv")

        if card_number and pin and cvv:
            Card.objects.create(
                card_number=card_number,
                pin=pin,
                cvv=cvv,
            )
            return redirect('add_card')  # Redirect to add card page after adding
    return render(request, "add_card.html")
from django.shortcuts import render
from .models import Account, Transaction

def transactions(request):
    account_holder_name = request.GET.get('account_holder_name')
    transactions = None
    error_message = None

    if account_holder_name:
        try:
            account = Account.objects.get(account_holder_name=account_holder_name)
            transactions = Transaction.objects.filter(account=account)

            if not transactions:
                error_message = f"No transactions found for {account_holder_name}."
        except Account.DoesNotExist:
            error_message = f"Account holder '{account_holder_name}' not found."

    return render(request, "tran.html", {
        "account_holder_name": account_holder_name,
        "transactions": transactions,
        "error_message": error_message
    })



from django.db.models.signals import pre_save
from django.dispatch import receiver

@receiver(pre_save, sender=Transaction)
def set_account_holder_name(sender, instance, **kwargs):
    if instance.account:
        instance.account_holder_name = instance.account.account_holder_name


from firstapp.models import Feedback

def feedback(request):
    if request.method == "POST":
        name = request.POST.get("name")
        email = request.POST.get("email")
        message = request.POST.get("message")

        if name and email and message:
            Feedback.objects.create(name=name, email=email, message=message)
            return render(request,"fs.html")  # Redirect after successful submission

    return render(request, "feedback.html")


from django.shortcuts import render, redirect
from django.contrib import messages
from decimal import Decimal
from .models import Account, Budget, Expense

def budget_page(request):
    account_holder_name = request.GET.get('account_holder_name')
    account = Account.objects.filter(account_holder_name=account_holder_name).first()
    
    total_budget = 0
    total_expenses = 0
    remaining_budget = 0
    expenses = []

    if account:
        budget = Budget.objects.filter(account=account).first()
        total_budget = budget.total_budget if budget else 0
        expenses = Expense.objects.filter(account=account)
        total_expenses = sum(exp.amount for exp in expenses)
        remaining_budget = total_budget - total_expenses

    return render(request, 'Budget.html', {
        'account_holder_name': account_holder_name,
        'total_budget': total_budget,
        'total_expenses': total_expenses,
        'remaining_budget': remaining_budget,
        'expenses': expenses
    })


def add_budget(request):
    if request.method == 'POST':
        account_holder_name = request.POST.get('account_holder_name')
        budget_amount = request.POST.get('budget_amount')

        account = Account.objects.filter(account_holder_name=account_holder_name).first()

        if account:
            budget, created = Budget.objects.get_or_create(account=account)
            budget.total_budget = Decimal(budget_amount)
            budget.save()
            messages.success(request, "Budget set successfully.")
        else:
            messages.error(request, "Account not found.")

    return redirect(f'/budget?account_holder_name={account_holder_name}')


def add_expense(request):
    if request.method == 'POST':
        account_holder_name = request.POST.get('account_holder_name')
        category = request.POST.get('category')
        amount = request.POST.get('amount')

        account = Account.objects.filter(account_holder_name=account_holder_name).first()

        if account and category and amount:
            Expense.objects.create(account=account, category=category, amount=Decimal(amount))
            messages.success(request, "Expense added successfully.")
        else:
            messages.error(request, "Invalid account or missing data.")

    return redirect(f'/budget?account_holder_name={account_holder_name}')


from django.shortcuts import get_object_or_404
from rest_framework.response import Response
from rest_framework.decorators import api_view
from firstapp.models import Account, Card, Data, Transaction, Feedback, Budget, Expense
from firstapp.serializers import (
    UserSerializer, AccountSerializer, CardSerializer, 
    TransactionSerializer, FeedbackSerializer, BudgetSerializer, ExpenseSerializer
)

# User Registration API
@api_view(['POST'])
def register_user(request):
    serializer = UserSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response({"message": "Registration successful"}, status=201)
    return Response(serializer.errors, status=400)

# User Login API
@api_view(['POST'])
def login_user(request):
    username = request.data.get("username")
    password = request.data.get("password")
    try:
        user = Data.objects.get(username=username)
        if user.password == password:
            return Response({"message": "Login successful", "username": user.username})
        return Response({"error": "Invalid password"}, status=400)
    except Data.DoesNotExist:
        return Response({"error": "User does not exist"}, status=404)

# Account Creation API
@api_view(['POST'])
def create_account(request):
    serializer = AccountSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response({"message": "Account created successfully"}, status=201)
    return Response(serializer.errors, status=400)

# Fetch Account Details API
@api_view(['GET'])
def get_account(request, account_holder_name):
    account = get_object_or_404(Account, account_holder_name=account_holder_name)
    serializer = AccountSerializer(account)
    return Response(serializer.data)

# Add Transaction API (Debit/Credit)
@api_view(['POST'])
def add_transaction(request):
    serializer = TransactionSerializer(data=request.data)
    if serializer.is_valid():
        transaction = serializer.save()
        
        # Update balance accordingly
        account = transaction.account
        if transaction.transaction_type == "debit":
            if account.balance >= transaction.amount:
                account.balance -= transaction.amount
                account.save()
                return Response({"message": "Debit successful"}, status=200)
            return Response({"error": "Insufficient balance"}, status=400)
        elif transaction.transaction_type == "credit":
            account.balance += transaction.amount
            account.save()
            return Response({"message": "Credit successful"}, status=200)

    return Response(serializer.errors, status=400)

# Get Transaction History API
@api_view(['GET'])
def get_transactions(request, account_holder_name):
    account = get_object_or_404(Account, account_holder_name=account_holder_name)
    transactions = Transaction.objects.filter(account=account)
    serializer = TransactionSerializer(transactions, many=True)
    return Response(serializer.data)

# Add Feedback API
@api_view(['POST'])
def submit_feedback(request):
    serializer = FeedbackSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response({"message": "Feedback submitted successfully"}, status=201)
    return Response(serializer.errors, status=400)

# Budget Management APIs
@api_view(['POST'])
def add_budget(request):
    serializer = BudgetSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response({"message": "Budget set successfully"}, status=201)
    return Response(serializer.errors, status=400)

@api_view(['POST'])
def add_expense(request):
    serializer = ExpenseSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response({"message": "Expense added successfully"}, status=201)
    return Response(serializer.errors, status=400)

@api_view(['GET'])
def get_budget(request, account_holder_name):
    account = get_object_or_404(Account, account_holder_name=account_holder_name)
    budget = Budget.objects.filter(account=account).first()
    expenses = Expense.objects.filter(account=account)

    total_expenses = sum(exp.amount for exp in expenses)
    remaining_budget = budget.total_budget - total_expenses if budget else 0

    return Response({
        "total_budget": budget.total_budget if budget else 0,
        "total_expenses": total_expenses,
        "remaining_budget": remaining_budget,
    })
