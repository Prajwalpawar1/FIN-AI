from django.db import models
from django.db import models

class Data(models.Model):
    username = models.CharField(max_length=100, unique=True,null=True)
    password = models.CharField(max_length=100,null=True)
    email = models.CharField(max_length=100,null=True)

    def __str__(self):
        return f"{self.username} - {self.email}"

    class Meta:
        db_table = "data"


class Account(models.Model):
    username = models.ForeignKey(Data, on_delete=models.CASCADE, related_name='accounts',null=True)
    account_holder_name = models.CharField(max_length=255,null=True)
    account_number = models.CharField(max_length=20, unique=True)
    ifsc_code = models.CharField(max_length=11,null=True)
    bank_name = models.CharField(max_length=255)
    balance = models.DecimalField(max_digits=12, decimal_places=2)

    def __str__(self):
        return f"{self.account_holder_name} - {self.bank_name} - {self.balance}"

    class Meta:
        db_table = "account"


class Card(models.Model):
    account = models.ForeignKey(Account, on_delete=models.CASCADE, related_name='cards',null=True)
    card_number = models.CharField(max_length=16, unique=True)
    pin = models.CharField(max_length=4)
    cvv = models.CharField(max_length=3)

    def __str__(self):
        return f"{self.card_number} - {self.pin} - {self.cvv}"

    class Meta:
        db_table = "card"

from django.db import models
from decimal import Decimal
from django.db import models

class Transaction(models.Model):
    TRANSACTION_TYPES = [
        ('credit', 'Credit'),
        ('debit', 'Debit'),
    ]

    account = models.ForeignKey('Account', on_delete=models.CASCADE, related_name='transactions', default=1)
    account_holder_name = models.CharField(max_length=255, blank=True, null=True)  # Store account holder's name
    transaction_type = models.CharField(max_length=6, choices=TRANSACTION_TYPES, null=True)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    timestamp = models.DateTimeField(auto_now_add=True, null=True)
    description = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"{self.transaction_type.capitalize()} of ₹{self.amount} on {self.timestamp.strftime('%Y-%m-%d %H:%M:%S')}"


class Feedback(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Feedback from {self.name} ({self.email})"

from django.db import models
from decimal import Decimal

class Budget(models.Model):
    account = models.ForeignKey('Account', on_delete=models.CASCADE, related_name="budgets", null=True)
    total_budget = models.DecimalField(max_digits=12, decimal_places=2, default=0.00)

    def __str__(self):
        return f"{self.account.account_holder_name} - Budget: ₹{self.total_budget}"

    class Meta:
        db_table = "budget"


class Expense(models.Model):
    CATEGORY_CHOICES = [
        ('Food', 'Food'),
        ('Transport', 'Transport'),
        ('Bills', 'Bills'),
        ('Entertainment', 'Entertainment'),
        ('Shopping', 'Shopping'),
        ('Others', 'Others'),
    ]

    account = models.ForeignKey('Account', on_delete=models.CASCADE, related_name="expenses", null=True)
    category = models.CharField(max_length=100, choices=CATEGORY_CHOICES, null=True)
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.account.account_holder_name} - {self.category}: ₹{self.amount}"

    class Meta:
        db_table = "expense"
