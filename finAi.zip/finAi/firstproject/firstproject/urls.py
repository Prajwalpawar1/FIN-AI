"""
URL configuration for firstproject project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path

from firstapp.models import Transaction
from firstapp.views import add_budget, add_expense, budget_page, givelogin, giveregister,login,registration,dashboard,home,account,add_account,add_card,tran,transactions,feedback,register_user,login_user,create_account,get_account,add_transaction,get_transactions,submit_feedback,get_budget
urlpatterns = [
    path('admin/', admin.site.urls),
    path('givelogin/',givelogin),
    path('giveregister/',giveregister),
    path('login/',login),
    path('registration/',registration),
    path('home/',home),
    path('dashboard/',dashboard),
    path('login/submit/', login, name='login'),
    path('home/', home, name='home'),
    path('givelogin/',givelogin,name='givelogin'),
    path('tran/',tran),
    path('feedback/',feedback),
    path('account/',account),
    path('add_account/',add_account),
    path('add_card/',add_card),
    path('account/',account,name='account'),
    path('dashboard/',dashboard,name='dashboard'),
    path('transactions/', transactions, name='transactions'),
    path('budget', budget_page, name='budget'),
    path('add_budget', add_budget, name='add_budget'),
    path('add_expense', add_expense, name='add_expense'),
     path('register/', register_user, name='register_user'),
    path('login/', login_user, name='login_user'),
    path('account/create/', create_account, name='create_account'),
    path('account/<account_holder_name>/', get_account, name='get_account'),
    path('transaction/add/', add_transaction, name='add_transaction'),
    path('transactions/<account_holder_name>/', get_transactions, name='get_transactions'),
    path('feedback/', submit_feedback, name='submit_feedback'),
    path('budget/add/', add_budget, name='add_budget'),
    path('expense/add/', add_expense, name='add_expense'),
    path('budget/<str:account_holder_name>/', get_budget, name='get_budget'),
# 
]
